export type LightingLook = string;

export interface EnhancementOptions {
  cleanup: boolean;
  removeObject: boolean;
  objectToRemove: string;
}
